package app.bean;
import java.io.Serializable;
import java.util.ArrayList;

//import java.util.ArrayList;

public class user implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String username;
	private String name;
	private String gender;
	private String DOB;
	private String pictureUrl;
	private String pictureText;
	private String description;
	private ArrayList<String> messageTo;
	private ArrayList<String> messageContent;
	private ArrayList<String> messageId;
	private ArrayList<String> messageTimeSent;
	private ArrayList<String> userlist;

	public void setId(String id) {
		this.id = id;
		}

	public String getId() {
		return this.id;
		}
	public void setUsername(String username) {
		this.username = username;
		}

	public String getUsername() {
		return this.username;
		}
	public void setName(String name) {
		this.name = name;
		}

	public String getName() {
		return this.name;
		}
	public void setGender(String gender) {
		this.gender = gender;
		}

	public String getGender() {
		return this.gender;
		}
	public void setDOB(String DOB) {
		this.DOB = DOB;
		}
	public String getDOB() {
		return this.DOB;
		}
	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
		}
	public String getPictureUrl() {
		return this.pictureUrl;
		}
	public void setPictureText(String pictureText) {
		this.pictureText = pictureText;
		}

	public String getDescription() {
		return this.description;
		}
	public void setDescription(String description) {
		this.description = description;
		}

	public String getPictureText() {
		return this.pictureText;
		}
	public void setMessageTo(ArrayList<String> messageTo) {
		this.messageTo = messageTo;
	}
	public ArrayList<String> getMessageTo() {
		return this.messageTo;
		}
	public ArrayList<String> getMessageContent() {
		return this.messageContent;
		}
	public void setMessageContent(ArrayList<String> messageContent) {
		this.messageContent = messageContent;
		}
	public ArrayList<String> getMessageId() {
		return this.messageId;
		}
	public void setMessageId(ArrayList<String> messageId) {
		this.messageId = messageId;
		}
	public ArrayList<String> getMessageTimeSent() {
		return this.messageTimeSent;
		}
	public void setMessageTimeSent(ArrayList<String> messageTimeSent) {
		this.messageTimeSent = messageTimeSent;
		}
	public ArrayList<String> getUserList() {
		return this.userlist;
		}
	public void setUserlist(ArrayList<String> userlist) {
		this.userlist = userlist;
		}
	
}