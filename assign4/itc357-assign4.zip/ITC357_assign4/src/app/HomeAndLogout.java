package app;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

//url to be accessed
@WebServlet("/logout")
public class HomeAndLogout extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//These Lines are executed when the servlet is browsed to directly. 
		HttpSession session = request.getSession(true);
		//terminate the user and so they have to login again to have access
		session.invalidate();
		RequestDispatcher rd=request.getRequestDispatcher("/login.jsp");
		rd.forward(request, response);
	}
}