package app;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//url to accessed through
@WebServlet("/setup")
public class Setup extends HttpServlet {
	private static final long serialVersionUID = 1L; //stop eclipse IDE complaining
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//database setup
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","abc123");
			java.sql.Statement statement=connection.createStatement();
			//see if database exists already
			ResultSet resultSet = connection.getMetaData().getCatalogs();
			boolean exists = false;
	        while (resultSet.next()) { //loop through and compare
	          String databaseName = resultSet.getString(1);
	            if(databaseName.equals("st11490893")){
	                exists = true;
	            }
	        }
	        resultSet.close();
	        if (exists != true){ //error, db exists, go back
	        	statement.executeUpdate("create database st11490893;");
	        	
	        }
	        //run sql statements to make database
			statement.executeUpdate("use ST11490893;");
			statement.executeUpdate("create table users(user_id int NOT NULL AUTO_INCREMENT,username char(20),password char(20),name char(30),DOB DATE,gender char(1), picture_url char(255) NOT NULL DEFAULT 'images/default.jpg', picture_text char(100), description char (255),PRIMARY KEY(user_id));");
			statement.executeUpdate("INSERT INTO `users` VALUES (1,'bgraham','ilikehome','Bill Graham','1990-04-26','M','images/surf.jpg','Surfing to Success','Im Billy'),"+
						"(2,'vsmith','gotoshops','Victoria Smith','1992-08-03','F','images/face.jpg','A face hiding behind a mask','Im the friendly Vic'),"+
						"(3,'fbee','farming','Fred Bee','1991-03-09','M','images/shock.jpg','A very shocked person','Im flopping around town fred'),"+
						"(4,'sboch','doorsarebad','Sarah Boch','1989-12-25','F','images/skate.jpg','Me and my Skateboard','Sarahs the name, ace is my game'),"+
						"(5,'cbridge','windows','Chloe Bridge','1990-08-22','F','images/default.jpg',NULL,'Im new here'),"+
						"(6,'testAccount','12345','Test user','1111-11-11','M','images/default.jpg',NULL,'A test user'),"+
						"(7,'CourtRulez','court','Courtney','1992-12-13','F','images/default.jpg',NULL,'I love fast cars and stuff');");
			statement.executeUpdate("CREATE TABLE messages (MESSAGE_ID INT NOT NULL AUTO_INCREMENT, " +
						"from_user_id INT NOT NULL," +
						"to_user_id INT NOT NULL," +
						"MESSAGE_CONTENT CHAR(255) NOT NULL, " +
						"time_sent timestamp NOT NULL, " +
						"owner_id INT NOT NULL, " +
						"PRIMARY KEY(MESSAGE_ID)," +
						"FOREIGN KEY (from_user_id) REFERENCES users (user_id)," +
						"FOREIGN KEY (to_user_id) REFERENCES users (user_id));");
			statement.executeUpdate("INSERT INTO `messages` VALUES (1,1,2,'from bill, hi vic','2013-10-01 07:30:16',1),"+
				"(2,1,2,'from bill, hi vic','2013-10-01 07:30:16',2),"+
				"(3,1,3,'from bill, hi fbee','2013-10-01 07:30:16',1),"+
				"(4,1,3,'from bill, hi fbee','2013-10-01 07:30:16',3),"+
				"(5,3,1,'from fbee, hi bill, good morning','2013-10-01 07:30:16',3),"+
				"(6,3,1,'from fbee, hi bill, good morning','2013-10-01 07:30:16',1),"+
				"(7,3,1,'from fbee, hi bill, what u doin','2013-10-01 07:30:16',3),"+
				"(8,3,1,'from fbee, hi bill, what u doin','2013-10-01 07:30:16',1),"+
				"(9,4,2,'Hi Victoria, did you see that post on twitter? from Sarah','2013-10-01 07:30:16',4),"+
				"(10,4,2,'Hi Victoria, did you see that post on twitter? from Sarah','2013-10-01 07:30:16',2),"+
				"(11,1,2,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:37',2),"+
				"(12,1,2,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',1),"+
				"(13,1,3,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',3),"+
				"(14,1,3,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',1),"+
				"(15,1,4,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',4),"+
				"(16,1,4,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',1),"+
				"(17,1,5,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',5),"+
				"(18,1,5,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',1),"+
				"(19,1,6,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',6),"+
				"(20,1,6,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',1),"+
				"(21,1,7,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',7),"+
				"(22,1,7,'Hi every, good day we are having. \r\nBut there has been a server glitch, we are restarting at 12pm\r\nSorry for inconvenience.\r\nFrom:\r\nBill and other admins','2013-10-01 07:38:38',1),"+
				"(23,4,1,'Thanks for updating us bill\r\nvery much appreciated!\r\n\r\nTar, Sarah','2013-10-01 07:40:52',1),(24,4,1,'Thanks for updating us bill\r\nvery much appreciated!\r\n\r\nTar, Sarah','2013-10-01 07:40:52',4);");
			connection.close(); //finish and back to home page
			request.setAttribute("setup", "Database has been created.");
			RequestDispatcher rd=request.getRequestDispatcher("/login.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	}
}
	