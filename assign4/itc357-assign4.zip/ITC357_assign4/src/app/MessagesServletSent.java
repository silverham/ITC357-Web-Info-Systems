package app;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import app.bean.user;

//url to be accessed through
@WebServlet("/messages_sent")
public class MessagesServletSent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//get the user bean
			HttpSession session = request.getSession(true);
			user currentUser = (user) session.getAttribute("currentUser");
			//get the messages
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/st11490893","root","abc123");
			java.sql.Statement statement=connection.createStatement();
			ResultSet res=statement.executeQuery("select MESSAGE_ID, name 'To:', time_sent, MESSAGE_CONTENT " +
					"from messages as M inner join users as U on M.to_user_id = U.user_id " +
					"Where M.from_user_id = "+currentUser.getId()+" and owner_id = "+currentUser.getId()+";");	
			// create an array list 
			ArrayList<String> messageId = new ArrayList<String>(); 
			ArrayList<String> messageTimeSent = new ArrayList<String>(); 
			ArrayList<String> messageTo = new ArrayList<String>(); 
			ArrayList<String> messageContent = new ArrayList<String>();
			//put the results on to an array list for easier processing
			while (res.next()) {
				messageId.add(res.getString(1));
				messageTo.add(res.getString(2));
				messageTimeSent.add(res.getString(3));
				//preprocessing for newlines
				String temp = res.getString(4);
				if (temp != null){
					temp = temp.replaceAll("\n", "<br />"); //convert system newlines into html new lines
					}
				messageContent.add(temp);
	        }
	        res.close();
	        //put arrays on the bean
	        currentUser.setMessageId(messageId);
	        currentUser.setMessageTo(messageTo);
	        currentUser.setMessageTimeSent(messageTimeSent);
	        currentUser.setMessageContent(messageContent);
	        
	        //bean back on session
	        session.setAttribute("currentUser", currentUser);
	        session.setAttribute("messagetype", "sent");
				RequestDispatcher rd=request.getRequestDispatcher("/messages.jsp");
				rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	}
}
	