package app;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import app.bean.user;

//serlet url
@WebServlet("/login")
public class login extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get the details from the login page
		//password1 used instead of password so that the register page can use this page also
		String username=request.getParameter("username");
		String password=request.getParameter("password1");
		boolean usernameSuccess = false, passwordSuccess = false; //assume failure
		try {
			//database stuff, the db name, user and pass, along with a connection and statement
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/st11490893","root","abc123");
			java.sql.Statement statement=connection.createStatement();
			ResultSet res=statement.executeQuery("select username, password from users;");
			while(res.next()){
				if(res.getString(1).equals(username)){ //username matches
					usernameSuccess = true;
				}
				if(res.getString(2).equals(password)){ //password 
					passwordSuccess = true;
				}
			}
			if(usernameSuccess == true && passwordSuccess == true){  //correct login
				user currentUser = new user(); //create the user
				res=statement.executeQuery("select * from users where username = '" + username + "';");
				if (res.next()) { //set most of the user attributes
					currentUser.setId(res.getString(1));
					currentUser.setUsername(res.getString(2));
					currentUser.setName(res.getString(4));
					currentUser.setDOB(res.getString(5));
					currentUser.setGender(res.getString(6));
					currentUser.setPictureUrl(res.getString(7));
					currentUser.setPictureText(res.getString(8));
					currentUser.setDescription(res.getString(9));
				}
				HttpSession session = request.getSession(true);//get the current seesion
				session.setAttribute("currentUser", currentUser); //put the user on the session
				RequestDispatcher rd=request.getRequestDispatcher("/welcome.jsp");
				rd.forward(request, response);
			}else{
				request.setAttribute("error", "Username or password is incorrect!"); //send back an error code
				request.setAttribute("username", username);
				RequestDispatcher rd=request.getRequestDispatcher("/login.jsp"); //go to this url, which is login.jsp
				rd.forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	}
}
