package app;
//import some utilities
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import app.bean.user;
//access this through this url
@WebServlet("/delete_messages")
public class DeleteMessages extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get the user bean
		HttpSession session = request.getSession(true);
		user currentUser = (user) session.getAttribute("currentUser");
		try {
			//get delete values
			String[] delete = request.getParameterValues("delete");
			//delete the messages
			Class.forName("com.mysql.jdbc.Driver"); //use this driver
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/st11490893","root","abc123"); //db, user, pass
			java.sql.Statement statement=connection.createStatement(); //make a statement object from connection
			for(int i=0; i<delete.length; i++){ //go through and delete the messages
				statement.executeUpdate("DELETE FROM messages WHERE MESSAGE_ID="+delete[i]+" and owner_id="+currentUser.getId()+";");
				}
	        //bean back on session and get feedback
			request.setAttribute("delete", "The selected messages were deleted.");
			RequestDispatcher rd=request.getRequestDispatcher("/messages_"+request.getParameter("messagetype"));
			rd.forward(request, response);
		} catch (SQLException e) { //catch the exception and debug on screen
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			}
	}
}
	