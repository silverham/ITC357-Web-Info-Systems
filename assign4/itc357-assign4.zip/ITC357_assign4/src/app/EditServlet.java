package app;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import app.bean.user;
//access through url
@WebServlet("/edit_profile")
public class EditServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get the user bean
		HttpSession session = request.getSession(true);
		user currentUser = (user) session.getAttribute("currentUser");
		request.setAttribute("instructions", "Edit your profile to continue."); //allows the registration to be reused with different instructions
		//display the current details
		request.setAttribute("username", currentUser.getUsername());
		request.setAttribute("name", currentUser.getName());				
		request.setAttribute("DOB", currentUser.getDOB());
		if(currentUser.getGender().equals("M"))
			request.setAttribute("genderM", "checked=\"checked\"");
		else{
			request.setAttribute("genderF", "checked=\"checked\"");		
		}
		request.setAttribute("pictureUrl", currentUser.getPictureUrl());
		request.setAttribute("pictureText", currentUser.getPictureText());
		session.setAttribute("description", currentUser.getDescription());
		request.setAttribute("type", "edit"); //set specifically which page
		RequestDispatcher rd=request.getRequestDispatcher("/registration.jsp");
		rd.forward(request, response);
	}	
}
	