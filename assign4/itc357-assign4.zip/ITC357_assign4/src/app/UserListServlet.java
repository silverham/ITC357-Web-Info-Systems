package app;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import app.bean.user;
//url
@WebServlet("/user_list")
public class UserListServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//get the bean
			HttpSession session = request.getSession(true);
			user currentUser = (user) session.getAttribute("currentUser");//get bean just for transport
			ArrayList<String> userList = new ArrayList<String>(); 
			//get the list
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/st11490893","root","abc123");
			java.sql.Statement statement=connection.createStatement();
			ResultSet res=statement.executeQuery("select username from users;");
			// create an array list 
			while (res.next()) {
				userList.add(res.getString(1));
	        }
	        res.close(); //close the result 
	        currentUser.setUserlist(userList);
	        session.setAttribute("currentUser", currentUser);
			RequestDispatcher rd=request.getRequestDispatcher("/user_list.jsp");
				rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	}
}
	