package app; //run within this package

import java.io.IOException; //import some functions
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import the function from our bean
import app.bean.user;
//this is how the servlet will be accessed, using this url
@WebServlet("/create_message")
public class CreateMessage extends HttpServlet {

	private static final long serialVersionUID = 1L; //stop eclipse will bugging us
	//run on post of a form
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type"); //either load the page or process the input from the page
		boolean error = false;
		if (type == null){ //if not processing a request
			RequestDispatcher rd=request.getRequestDispatcher("/create_message.jsp"); //go  to page
			rd.forward(request, response);
		}else{//else, process the create message request
			//obtain the form fields	
			String[] username =  request.getParameterValues("username");
			String message = request.getParameter("message");
			
			//make separate variables that are valid (if correct, the message will be put in these and sent)
			//The original username contains could contain blanks
			//made for simplicity
			ArrayList<String> sendtoUsername = new ArrayList<String>();  //(arraylist)
			
			//check the variables
			int usernamesAllEmpty = 0;
			int numberOfTextboxes = 6; //this is the number of textboxes we will use
			//check fields
			for (int i = 0; i < username.length; i++){
				if(username[i].isEmpty())usernamesAllEmpty++; //count how many empty fields
				}
			if (usernamesAllEmpty >= numberOfTextboxes){ //six fields, if all empty, then produce error
				request.setAttribute("error", "At least one user must be entered!");
				error = true;
			}
			//no errors, lets continue
			if (error == false){
				try {
					//check if username exists
					Class.forName("com.mysql.jdbc.Driver"); //connect to database - using this driver
					java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/st11490893","root","abc123"); //a url and username and password
					java.sql.Statement statement=connection.createStatement(); //
						ResultSet res=statement.executeQuery("select username from users;"); //get data from database
						ArrayList<String> resArray = new ArrayList<String>();
						while (res.next()) {
							resArray.add(res.getString(1)); //parse the result into arraylist for recursion
							}
						res.close(); //close the result, it's unneeded and resource heavy
						int i = 0; //make an index
						String[] usernameError = new String[numberOfTextboxes]; //an array to track which textboxe errors out
						while (i < username.length){  //loop through usernames
							request.setAttribute("username"+ (i+1), username[i]); //send the username back to webpage if this fail
							int ii = 0;
							while (resArray.size() > ii) { //loop through each database username
								if(!username[i].isEmpty()){ //not empty - username entered (skip empty usernames)
									if(resArray.get(ii).equals(username[i])){
										//success, the username exists
										usernameError[i] = "found"; //find one that did work
										sendtoUsername.add(username[i]);  //add it to the sending list
										break; //get out of while loop
									}
								}
								ii++; //next username
							}
							ii--; //make usernameError go back one, so it is correct
							if(usernameError[i] != "found" && !(username[i].isEmpty()) ){ //username not found and that username entry exists
								error = true; //found an error
								request.setAttribute("errorUsername"+ (i+1), "This username doesn't not exist!"); //brackets used as java will cast them to string otherwise
								
							}
							i++; //go through next database  entry
						}
			        //other variables are correct and username exists
			       if(error == false){
			    	   //find user id's
			    	   ArrayList<String> sendtoId = new ArrayList<String>(); //used for actual message
			    	   //convert usernames to id's
			    	   for (i=0; i < sendtoUsername.size(); i++){
				    	   res=statement.executeQuery("select user_id from users where username = '"+sendtoUsername.get(i)+"';");
				    	   res.next();
				    	   sendtoId.add(res.getString(1));
			    	   }
			    	//get the user bean
			   		HttpSession session = request.getSession(true);
			   		user currentUser = (user) session.getAttribute("currentUser");
			   		//escape the apostrophe's
			   		message = message.replaceAll("'", "''");
			    	//input the message
			      	for (i=0; i < sendtoId.size(); i++){
			      		//once for the sender (so that one delete doesn't delete from both boxes (sent and other's inbox)
			       		statement.executeUpdate("insert into messages (from_user_id, to_user_id, owner_id, MESSAGE_CONTENT) " +
			       				"values ("+currentUser.getId()+", "+sendtoId.get(i)+", "+sendtoId.get(i)+", '"+message+"');");
			       		//another for the receiver
			       		statement.executeUpdate("insert into messages (from_user_id, to_user_id, owner_id, MESSAGE_CONTENT) " +
			       				"values ("+currentUser.getId()+", "+sendtoId.get(i)+", "+currentUser.getId()+", '"+message+"');");
			        		}
			        }
			        connection.close();
			} catch (SQLException e) { //catach and debug via printing error
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				}
			}
			//back to the last page if an error
			if(error == true){
				//put the message back on the page
				request.setAttribute("message", message);
	        	RequestDispatcher rd=request.getRequestDispatcher("/create_message.jsp");
	    		rd.forward(request, response);
			}else{
				//success! go forward to put deeback on the welcome page
				request.setAttribute("feebackFromAnotherPage", "Message was successfully sent!");
				RequestDispatcher rd=request.getRequestDispatcher("/welcome.jsp");
				rd.forward(request, response);
			}
		
		} //end of process request
	} //http request
}
	