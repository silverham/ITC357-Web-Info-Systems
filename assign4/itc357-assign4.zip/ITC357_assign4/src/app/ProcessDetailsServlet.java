package app;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import app.bean.user;

//url access
@WebServlet("/register")
public class ProcessDetailsServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type"); //get which type of process were are processing
		if (type.equals("goToRegistrationPage")){
			request.setAttribute("instructions", "Enter your details to register.");
			RequestDispatcher rd=request.getRequestDispatcher("/registration.jsp");
			rd.forward(request, response);
		}else{//else, process the registration/edit request
			//obtain the form fields	
			String username = request.getParameter("username");
			String name = request.getParameter("name");
			String DOB = request.getParameter("DOB");
			String gender = request.getParameter("gender");
			String pictureUrl = request.getParameter("pictureUrl");
			String pictureText = request.getParameter("pictureText");
			String description = request.getParameter("description");
			String password1 = request.getParameter("password1");
			String password2 = request.getParameter("password2");
			
			//get the current logged(user bean) in user if any
			HttpSession session = request.getSession(true);
			user currentUser = (user) session.getAttribute("currentUser");
			
			//check the variables
			boolean error = false;
			//check name
			if (name == null || name.isEmpty()){
				request.setAttribute("errorName", "Enter a name!.");
				error = true;
			}
			if (DOB == null || DOB.isEmpty()){
				request.setAttribute("errorDOB", "Enter a Date of Birth!.");
				error = true;
			}
			if (gender == null || gender.isEmpty()){
				request.setAttribute("errorGender", "Please click a gender!.");
				error = true;
			}else{ //remember gender here instead of jsp as checkboxes are more complex
				if(gender.equals("M"))
					request.setAttribute("genderM", "checked=\"checked\""); // \ escapes the speech marks
				else{
					request.setAttribute("genderF", "checked=\"checked\"");		
				}
			}
			//check pictureText, url must be present also
			if (pictureUrl == null || pictureUrl.isEmpty()){
				if (pictureText.isEmpty() == false){
					request.setAttribute("errorPictureText", "WHAT?! An Alternative picture text can only enter with picture (url)!");
					error = true;
				}
			}
			if (password1 == null || (!password1.equals(password2))){ //if different passwords used
				error = true;
				request.setAttribute("errorPassword", "Passwords do not match, please type the same password.");
				}else{
					if(password1.isEmpty()){
						error = true;
						request.setAttribute("errorPassword", "No password entered, please type the password to use later.");
						}else{
							request.setAttribute("password", password1);
							}
					}
			if (username == null || username.isEmpty()){
				error = true;
				request.setAttribute("errorUsername", "The username field is empty!");
			}else{
				try {
					//check if username exists
					Class.forName("com.mysql.jdbc.Driver");
					java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/st11490893","root","abc123");
					java.sql.Statement statement=connection.createStatement();
					ResultSet res=statement.executeQuery("select username from users;");
					while (res.next()) {
						if(res.getString(1).equals(username)){
							//if not logged in or are logged in but this not your username
							if(currentUser == null || !currentUser.getUsername().equals(username)){ 
								error = true;
								request.setAttribute("errorUsername", "The username is already taken!");
								break;
							}
						}
			        }
			        res.close();
			        //other variables are correct and username not taken
			        //so we create the user and log him/her in.
			        if(error == false){
			        	//convert description's newline character, do it here instead or eariler instead an error comes
			        	//and the descirption put back on reg page is not the same 
			    		description = description.replaceAll(System.getProperty("line.separator"), "<br />");
			        	//create or update
			    		if (type.equals("edit")){
			    			if(pictureUrl.isEmpty()){
			    				statement.executeUpdate("UPDATE users SET username=\""+username+"\", password=\""+password1+"\",name=\""+name+
				    					"\", DOB=\""+DOB+"\", gender=\""+gender+"\", description=\""+description+"\" " +
				    					"WHERE user_id="+currentUser.getId()+";");
			    			}else{//separate statement for no pictureUrl, so that the default will be inserted
			    				statement.executeUpdate("UPDATE users SET username=\""+username+"\", password=\""+password1+"\",name=\""+name+
				    					"\", DOB=\""+DOB+"\", gender=\""+gender+"\", description=\""+description+"\", picture_url=\""+pictureUrl+
				    					"\", picture_text=\""+pictureText+"\"" +
				    					"WHERE user_id="+currentUser.getId()+";");
			    			}
			    		}else{ //create profile
			    			if(pictureUrl.isEmpty()){
				        		statement.executeUpdate("insert into users (username, password, name, DOB, gender, description)" +
				        				"values (\""+username+"\",\""+password1+"\",\""+name+"\", \""+DOB+"\", \""+gender+"\", \""+description+"\");");
				        	}else{ 
				        		statement.executeUpdate("insert into users (username, password, name, DOB, gender, picture_url, picture_text, description)" +
				        				"values (\""+username+"\",\""+password1+"\",\""+name+"\", \""+DOB+"\", \""+gender+"\", \""+pictureUrl+"\", \""+pictureText+"\", \""+description+"\");");
				        	}	
			        	}
			        	RequestDispatcher rd=request.getRequestDispatcher("/login");
						rd.forward(request, response);
			        }
			        connection.close();
	
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
			}
			//on error, give the variables back to the page 
			if(error == true){
				request.setAttribute("instructions", "Correct the errors to continue."); //it's an
				request.setAttribute("username", username);
				request.setAttribute("name", name);
				request.setAttribute("DOB", DOB);
				request.setAttribute("pictureUrl", pictureUrl);
				request.setAttribute("pictureText", pictureText);
				request.setAttribute("description", description);
	        	request.setAttribute("error", "There was an error processing user details, see below.");
	        	RequestDispatcher rd=request.getRequestDispatcher("/registration.jsp");
	    		rd.forward(request, response);
	
	        }
		}
	}	
}
	