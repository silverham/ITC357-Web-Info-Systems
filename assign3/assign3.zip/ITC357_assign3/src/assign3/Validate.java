package assign3;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//These Lines are executed when the servlet is browsed to directly. 
		request.setAttribute("errorNotFilledOut", "Form was not submited! Please fill out out.");
		RequestDispatcher rd=request.getRequestDispatcher("/Registration.jsp");
		rd.forward(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {		
		//obtain the form fields	
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String temp = request.getParameter("address"); //temp is temporary value
		String[] address = temp.split("\n");
		temp = null; //delete temp
		String birthday = request.getParameter("birthday");
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		String roomType = request.getParameter("roomType");
		String location = request.getParameter("location");
		String[] services = request.getParameterValues("services");
		String time = request.getParameter("time");
		
		boolean error = false; // initialize error variable
		
		if (firstname == null || firstname.equals("")){
			request.setAttribute("errorFirstName", "First name not entered, please enter it!");
			error = true;
		}
		if (lastname == null || lastname.equals("")){
			request.setAttribute("errorLastName", "Last name not entered, please enter it!");
			error = true;
		}
		if (address == null || address[0].equals("")){
			request.setAttribute("errorAddress", "Address not entered, please enter it!");
			error = true;
		}
		if (birthday == null || birthday.equals("")){
			request.setAttribute("errorBirthday", "Birthday not entered, please enter it!");
			error = true;
		}
		if (!password1.equals(password2)){ //if different passwords
			error = true;
			request.setAttribute("errorPassword", "Passwords do not match, please type the same password.");
			}else{
				if(password1.equals("")){
					error = true;
					request.setAttribute("errorPassword", "No password entered, please type the password to use later.");
					}else{
						request.setAttribute("password", password1);
						}
				}
		if (roomType == null || roomType.equals("")){
			request.setAttribute("errorRoomType", "An error occurred processing room type.");
			error = true;
		}
		if (location == null || location.equals("")){
			request.setAttribute("errorLocation", "An error occurred processing the Location of hotel chosen.");
			error = true;
		}
		if (services.length == 0 ){
			request.setAttribute("errorServices", "An error occurred processing the services.");
			error = true;
		}
		if (time == null){
			request.setAttribute("errorTime", "An error occurred processing the time of day to book in.");
			error = true;
		}
		
		//setAttribute is used so the the forwarded page can use Expression Language
		//which is cleaner compared to coding scriptlets
		request.setAttribute("firstname", firstname); 
		request.setAttribute("lastname", lastname); 
		request.setAttribute("birthday", birthday); 
		request.setAttribute("password", password1); 
		request.setAttribute("roomType", roomType); 
		request.setAttribute("location", location); 
		request.setAttribute("time", time); 
		//Note: the "services" and "address" is set here as processing is needed on the confirmation
		//page, processing to display on different lines
		
		if (error == true){ //An error did occur
			RequestDispatcher rd=request.getRequestDispatcher("/Registration.jsp");
			rd.forward(request, response);
			}
		if (error == false){ //no error occurred
			RequestDispatcher rd=request.getRequestDispatcher("/Confirmation.jsp");
			rd.forward(request, response);
			}
		}
		
}

